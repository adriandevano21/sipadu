<?php
defined('BASEPATH') or exit('No direct script access allowed');


/**
 *
 * Controller Cronjob
 *
 * This controller for ...
 *
 * @package   CodeIgniter
 * @category  Controller CI
 * @author    Setiawan Jodi <jodisetiawan@fisip-untirta.ac.id>
 * @author    Raul Guerrero <r.g.c@me.com>
 * @link      https://github.com/setdjod/myci-extension/
 * @param     ...
 * @return    ...
 *
 */

class Cronjob extends CI_Controller
{
    
  public function __construct()
  {
    parent::__construct();
    $this->load->model("master_model");
  }

  public function update_aktif_qr()
  {
    
    $this->master_model->update('qrcode', 'tanggal <', date("Y:m:d"),  array('aktif' => 0 ) );
  }

}


/* End of file Cronjob.php */
/* Location: ./application/controllers/Cronjob.php */