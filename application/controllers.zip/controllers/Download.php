<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Download extends CI_Controller
{
    private $token_ = "_{ptZD^ei_u=ZFyV9Y|j_v1VOYXLPB|7}gTBl^hEP4vx}hpk-ichsan";
    private $DEVICE_ID = "iphone";


    public function __construct()
    {
        parent::__construct();

        $this->load->model('surat_masuk_model');
        $this->load->model('master_model');
        $this->load->model('pegawai_model');
        $this->load->model('tim_model');
    }



    public function surat_masuk($file_surat)
    {
        //load the download helper
        $this->load->helper('download');
        // $params = array(
        //     'id_surat' => $id_surat,
        //     'username' => $this->session->userdata('username')
        // );
        // $this->surat_model->add_download($params);
        //$this->transaksi_model->update_read($id_transaksi);

        header("Content-Type:  application/pdf ");
        force_download("upload_file/surat_masuk/" . $file_surat, NULL);
    }
}
