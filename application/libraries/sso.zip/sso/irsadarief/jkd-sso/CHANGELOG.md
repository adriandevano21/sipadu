# Changelog
All Notable changes to `jkd-sso` will be documented in this file

## 0.1.0 - 2020-01-20

### Added
- Initial release!

### Deprecated
- Nothing

### Fixed
- Nothing

### Removed
- Nothing

### Security
- Nothing

## .1.0 - 2020-01-20

### Added

### Deprecated
- Nothing

### Fixed
- Nothing

### Removed
- Nothing

### Security
- Nothing


## 1.0.0 - 2020-02-13

### Added
- Readme 

### Deprecated
- Nothing

### Fixed
- Nothing

### Removed
- Nothing

### Security
- Nothing

## 1.1.0 - 2020-02-20

### Added
- Update Readme

### Deprecated
- Nothing

### Fixed
- Nothing

### Removed
- Nothing

### Security
- Nothing

## 1.2.0 - 2020-04-27

### Added
- Update Readme & ResourceOwner Functions

### Deprecated
- Nothing

### Fixed
- Realm : pegawai-bps

### Removed
- Nothing

### Security
- Nothing

## 1.3.0 - 2020-05-19

### Added
- Update Readme & ResourceOwner Functions To Accomodate Attribute Foto

### Deprecated
- Nothing

### Fixed
- Nothing

### Removed
- Nothing

### Security
- Nothing
