<!DOCTYPE html>
<html>

<head>
    <title><?php echo $title; ?></title>
    <!-- Tambahkan CSS atau style jika diperlukan -->
</head>

<body>
    <h1><?php echo $title; ?></h1>

    <strong>Version 1 :</strong>
    <ul>
        <li>
            deploy awal sipadu
        </li>
        <li>
            fitur kegiatanku
        </li>
        <li>
            fitur rapat
        </li>
        <li>
            fitur presensi dengan barcode
        </li>
        <li>
            fitur booking zoom
        </li>
        <li>
            fitur upload SK
        </li>

    </ul>
    <strong>Version 1.1 (24-11-2023) :</strong>
    <ul>
        <li>
            Menambahkan pemimpin rapat di notif WA
        </li>
        <li>
            Menambahkan fitur agenda (CRUD)
        </li>
        <li>
            Menambahkan fitur hapus event
        </li>

    </ul>
    <strong>Version 1.1 (19-01-2024) :</strong>
    <ul>
        <li>
            [Event] mengubah narahubung dari notulis menjadi pembuat rapat
        </li>
        <li>
            [Kegiatan] Menambahkan fungsi untuk dapat melihat kegiatan beberapa pegawai sekaligus dari tanggal 1-31
        </li>

    </ul>
    <strong>Version 1.1 (22-01-2024) :</strong>
    <ul>
        <li>
            [Kegiatan] menambahkan fitur projek 
        </li>
        <li>
            [Kegiatan] menambahkan form projek pada pengisian kegiatan sehari hari
        </li>

    </ul>


    <!-- Tambahkan script atau footer jika diperlukan -->
</body>

</html>