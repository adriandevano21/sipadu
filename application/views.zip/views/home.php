<div class="card">
    <!-- <div class="card-header header-elements-inline">
        <h5 class="card-title">Tambah Aktivitas</h5>
        <div class="header-elements">
            <div class="list-icons">
                <a class="list-icons-item" data-action="collapse"></a>
                <a class="list-icons-item" data-action="reload"></a>
                <a class="list-icons-item" data-action="remove"></a>
            </div>
        </div>
    </div> -->

    <div class="card-body" style="background-image: url('<?= base_url(); ?>/global_assets/images/bg_aceh.jpg');">
        <div class="col-md-5">
            ahsjhashfahf
            <br><br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>


        </div>
        <div class="col-md-5">
            ajfajsflkajl
            <br>
            <br><br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
        </div>


    </div>
</div>