<script src="<?= base_url(); ?>/global_assets/js/plugins/editors/ckeditor/ckeditor.js"></script>
<script src="<?= base_url(); ?>/global_assets/js/demo_pages/editor_ckeditor.js"></script>
<script src="<?= base_url(); ?>/global_assets/js/demo_pages/gallery.js"></script>
<script src="<?= base_url(); ?>/global_assets/js/plugins/media/fancybox.min.js"></script>
<!-- CKEditor default -->
<div class="card">
    <div class="card-header header-elements-inline">
        <h5 class="card-title">Detail Perjalanan Dinas</h5>
        <input type="button" value="Back" onclick="history.back(-1)" class=" btn btn-primary" />
        <!-- <div class="header-elements">
            <div class="list-icons">
                <a class="list-icons-item" data-action="collapse"></a>
                <a class="list-icons-item" data-action="reload"></a>
                <a class="list-icons-item" data-action="remove"></a>
            </div>
        </div> -->
    </div>
            

    <div class="card-body">
                <table class="table">
                
                <tr>
                    <td>Nama</td>
                    <td>:</td>
                    <td><?= $detail_perjadin['nama_pegawai']; ?></td>
                </tr>
                <tr>
                    <td width='10%'>Judul </td>
                    <td width='5%'>: </td>
                    <td><?= $detail_perjadin['judul']; ?></td>
                </tr>
                <tr>
                    <td>Deskripsi</td>
                    <td>:</td>
                    <td><?= $detail_perjadin['deskripsi']; ?></td>
                </tr>
                <tr>
                    <td>Tanggal</td>
                    <td>:</td>
                    <td><?= $detail_perjadin['tanggal_pergi']; ?> sampai <?= $detail_perjadin['tanggal_pulang']; ?></td>
                </tr>
                <tr>
                    <td>Durasi</td>
                    <td>:</td>
                    <td><?= $detail_perjadin['durasi']; ?> hari</td>
                </tr>
                <tr>
                    <td>Tujuan</td>
                    <td>:</td>
                    <td><?= $detail_perjadin['nama_satker']; ?></td>
                </tr>
            </table>
        
        <br>
        <!-- <p class="mb-3">CKEditor is a ready-for-use HTML text editor designed to simplify web content creation. It's a WYSIWYG editor that brings common word processor features directly to your web pages. It benefits from an active community that is constantly evolving the application with free add-ons and a transparent development process.</p> -->
        <h4>Permasalahan</h4>
        <table width='100%'>
            <tr>
                <td>
                    <span>
                        <?= $detail_perjadin['permasalahan']; ?>
                    </span>
                </td>
            </tr>
        </table>
        <h4>Solusi</h4>
        <table width='100%'>
            <tr>
                <td>
                    <span>
                        <?= $detail_perjadin['solusi']; ?>
                    </span>
                </td>
            </tr>
        </table>
        <h4>Dokumentasi Perjalanan Dinas </h4>
        <div class="row">
            <?php foreach ($dokumentasi_perjadin as $key => $value) {
                
            ?>
            <div class="col-sm-6 col-lg-3">
                <div class="card">
                    <div class="card-img-actions m-1">
                        <span><?=$value['caption'] ?></span>
                        <img class="card-img img-fluid" src="<?= base_url('upload_file/perjadin/').$value['nama_file'] ?>" alt="">
                        <div class="card-img-actions-overlay card-img">
                            <a href="<?= base_url('upload_file/perjadin/').$value['nama_file'] ?>" class="btn btn-outline bg-white text-white border-white border-2 btn-icon rounded-round" data-popup="lightbox" rel="group">
                                <i class="icon-plus3"></i>
                            </a>

                            <a href="#" class="btn btn-outline bg-white text-white border-white border-2 btn-icon rounded-round ml-2">
                                <i class="icon-link"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>

            
        </div>

    </div>
</div>
<!-- /CKEditor default -->