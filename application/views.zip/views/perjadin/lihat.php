<script src="<?= base_url(); ?>/global_assets/js/plugins/uploaders/fileinput/plugins/purify.min.js"></script>
<script src="<?= base_url(); ?>/global_assets/js/plugins/uploaders/fileinput/plugins/sortable.min.js"></script>
<script src="<?= base_url(); ?>/global_assets/js/plugins/uploaders/fileinput/fileinput.min.js"></script>

<script src="<?= base_url(); ?>/global_assets/js/plugins/editors/ckeditor/ckeditor.js"></script>
<script src="<?= base_url(); ?>/global_assets/js/demo_pages/editor_ckeditor.js"></script>
<script src="<?= base_url(); ?>/global_assets/js/demo_pages/uploader_bootstrap.js"></script>
<script src="<?= base_url(); ?>/global_assets/js/demo_pages/gallery.js"></script>
<script src="<?= base_url(); ?>/global_assets/js/plugins/media/fancybox.min.js"></script>
<?php
if ($this->session->flashdata('sukses') <> '') {
?>
    <div class="alert alert-success alert-dismissible " role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
        </button>
        <span><?php echo $this->session->flashdata('sukses'); ?></span>
    </div>
<?php
}
?>
<?php
if ($this->session->flashdata('gagal') <> '') {
?>
    <div class="alert alert-danger alert-dismissible " role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
        </button>
        <span><?php echo $this->session->flashdata('gagal'); ?></span>
    </div>
<?php
}
?>
<!-- Basic datatable -->
<div class="card">
    <div class="card-header header-elements-inline">
        <h5 class="card-title">Kumpulan Perjadin</h5>
        <a href="<?= base_url(); ?>/perjadin/tambah">
            <button type="button" class="btn btn-outline-success"><i class="icon-plus2 mr-2"></i> Perjadin</button>
        </a>
        <div class="header-elements">
            <div class="list-icons">
                <a class="list-icons-item" data-action="collapse"></a>
                <!-- <a class="list-icons-item" data-action="reload"></a> -->
                <a class="list-icons-item" data-action="remove"></a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <form method="get" action="<?= base_url(); ?>/perjadin/lihat">
            <div class="form-group row">
                <label class="col-form-label col-sm-1">Bulan</label>
                <div class="col-sm-4">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group ">
                                <select name="bulan" class="form-control">
                                    <option value=<?= $bulan; ?>><?= $bulan; ?></option>
                                    <option value="01">01</option>
                                    <option value="02">02</option>
                                    <option value="03">03</option>
                                    <option value="04">04</option>
                                    <option value="05">05</option>
                                    <option value="06">06</option>
                                    <option value="07">07</option>
                                    <option value="08">08</option>
                                    <option value="09">09</option>
                                    <option value="10">10</option>
                                    <option value="11">11</option>
                                    <option value="12">12</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <label class="col-form-label col-sm-1">Tahun</label>
                <div class="col-sm-4">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group ">
                                <select name="tahun" class="form-control">
                                    <option value=<?= $tahun; ?>><?= $tahun; ?></option>
                                    <option value="2022">2022</option>
                                    <option value="2023">2023</option>
                                    <option value="2024">2024</option>
                                    <option value="2025">2025</option>
                                    <option value="2026">2026</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-2">
                    <button type="submit" class="btn btn-outline-primary"><i class="icon-search4 mr-2"></i> Filter</button>
                </div>
            </div>

        </form>
    </div>

    <table class="table datatable-button-html5-basic">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Tanggal</th>
                <th>Durasi</th>
                <th>Tujuan/Tugas</th>
                <th>Tempat Tujuan</th>
                <th>Status</th>
                <th class="text-center">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($perjadin as $key => $value) {
            ?>
                <tr>
                    <td>
                        <?php echo $value['nama_pegawai']; ?>

                    </td>
                    <td class="text-center">
                        <?php echo $value['tanggal_pergi']; ?>
                    </td>
                    <td>
                        <?php echo $value['durasi']; ?> hari
                    </td>
                    <td>
                        <?php echo $value['judul']; ?>
                    </td>
                    <td>
                        <?php echo $value['nama_satker']; ?>
                    </td>
                    <td class="text-center">
                        <?php
                        if ($value['status'] == "disetujui") { ?>
                            <span class="badge badge-flat border-primary text-primary-600"><?php echo $value['status']; ?></span>
                        <?php
                        } else if ($value['status'] == "selesai") { ?>
                            <span class="badge badge-flat border-success text-success-600"><?php echo $value['status']; ?></span>
                        <?php
                        } else if ($value['status'] == "diajukan") { ?>
                            <span class="badge badge-flat border-warning text-warning-600"><?php echo $value['status']; ?></span>
                        <?php
                        } else if ($value['status'] == "ditolak") { ?>
                            <span class="badge badge-flat border-danger text-danger-600"><?php echo $value['status']; ?></span>
                        <?php
                        } else if ($value['status'] == "laporan selesai") { ?>
                            <span class="badge badge-flat border-success text-success-600"><?php echo $value['status']; ?></span>
                        <?php
                        }
                        ?>
                    </td>
                    <td class="text-center">

                        <a href="<?= base_url(); ?>perjadin/detail/<?= $value['id_perjadin'] ?>" data-popup="tooltip" title="Lihat"><i class="icon-eye"></i></a>

                        <?php
                        if ($value['status'] == "ditolak" || $value['status'] == "disetujui"  || $value['status'] == "laporan selesai") {
                        } else if ($this->session->userdata('username') == "ahmadriswan") { ?>

                            <a href="#" data-toggle="modal" data-target="#modal_setujui" data-judul="<?php echo $value['judul']; ?>" data-id_perjadin="<?php echo $value['id_perjadin']; ?>" data-nama_pegawai="<?php echo $value['nama_pegawai']; ?>" data-tanggal_pergi="<?php echo $value['tanggal_pergi']; ?>" data-tanggal_pulang="<?php echo $value['tanggal_pulang']; ?>" data-durasi="<?php echo $value['durasi']; ?>" data-nama_satker="<?php echo $value['nama_satker']; ?>" data-deskripsi="<?php echo $value['deskripsi']; ?>" data-popup="tooltip" title="Setujui atau Tolak">
                                <i class="icon-checkmark text-warning"></i>
                            </a>
                        <?php } ?>


                        <a href="<?= base_url(); ?>perjadin/input_laporan/<?= $value['id_perjadin'] ?>" data-judul="<?php echo $value['judul']; ?>" data-id_perjadin="<?php echo $value['id_perjadin']; ?>" data-popup="tooltip" title="Input Laporan">
                            <i class="icon-pencil"></i>
                        </a>




                    </td>

                </tr>
            <?php
            }
            ?>

        </tbody>
    </table>
</div>

<!-- Vertical form modal -->
<div id="modal_selesai" class="modal fade" tabindex="-1">
    <div class="modal-dialog modal-full">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Laporan Perjalanan Dinas</h5>
                <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
            </div>

            <form method="post" action="<?= base_url(); ?>/perjadin/input_laporan" enctype="multipart/form-data">
                <input type="hidden" name="id_perjadin" id="id_perjadin">
                <div class="modal-body">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-sm-12">
                                <label>
                                    <h2>Judul</h2>
                                </label>

                                <textarea class="form-control" disabled id="judul" rows="2"></textarea>
                                <!-- <input type="text" class="form-control" disabled id="selesai"> -->
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="mb-3">

                            </div>
                            <div class="col-sm-12">
                                <label>
                                    <h2>Permasalahan</h2>
                                </label>
                                <textarea name="permasalahan" id="editor-full1" class="editor-full" rows="2" cols="2" required></textarea>
                                <!-- <textarea class="form-control" id="permasalahan" rows="3" required></textarea> -->
                                <!-- <input type="text" class="form-control" disabled id="selesai"> -->
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="mb-3">

                            </div>
                            <div class="col-sm-12">
                                <label>
                                    <h2>Solusi</h2>
                                </label>
                                <textarea id="editor-full2" class="editor-full" name="solusi" rows="2" cols="2" name="solusi" required></textarea>
                                <!-- <input type="text" class="form-control" disabled id="selesai"> -->
                            </div>
                        </div>
                    </div>
                    <div class="form-group ">
                        <div class="row">
                            <div class="mb-3">

                            </div>
                            <label>
                                <h2>Upload Foto</h2>
                            </label>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <input type="file" class="file-input" data-fouc name="upload_foto1" accept="image/*">
                                <label>
                                    Caption Foto 1 (maks 300kb)
                                </label>
                                <input class="form-control" name="caption1" placeholder="caption foto 1" required></input>
                            </div>
                            <div class="col-sm-6">
                                <input type="file" class="file-input" data-fouc name="upload_foto2" accept="image/*">
                                <label>
                                    Caption Foto 2 (maks 300kb)
                                </label>
                                <input class="form-control" name="caption2" placeholder="caption foto 2" required></input>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn bg-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- /vertical form modal -->

<!-- Vertical form modal -->
<div id="modal_setujui" class="modal fade" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Laporan Perjalanan Dinas</h5>
                <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
            </div>


            <input type="hidden" name="id_perjadin" id="id_perjadin">
            <div class="modal-body">
                <table class="table">
                    <tr>
                        <td>Nama</td>
                        <td>:</td>
                        <td><span id="nama_pegawai_setujui"></td>
                    </tr>
                    <tr>
                        <td width='10%'>Judul </td>
                        <td width='5%'>: </td>
                        <td><span id="judul_setujui"></td>
                    </tr>
                    <tr>
                        <td>Deskripsi</td>
                        <td>:</td>
                        <td><span id="deskripsi_setujui"></td>
                    </tr>
                    <tr>
                        <td>Tanggal</td>
                        <td>:</td>
                        <td><span id="tanggal_setujui"> : <span id="tanggal_pulang_setujui"></td>
                    </tr>
                    <tr>
                        <td>Durasi</td>
                        <td>:</td>
                        <td><span id="durasi_setujui"> hari</td>
                    </tr>
                    <tr>
                        <td>Tujuan</td>
                        <td>:</td>
                        <td><span id="nama_satker_setujui"></td>
                    </tr>
                </table>



            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
                <a href="" id="link_tolak">
                    <button type="button" class="btn bg-danger">Tolak</button>
                </a>
                <a href="" id="link_setujui">
                    <button type="button" class="btn bg-primary">Setujui</button>
                </a>
            </div>

        </div>
    </div>
</div>
<!-- /vertical form modal -->


<!-- Vertical form modal -->
<div id="modal_lihat" class="modal fade" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail Perjalanan Dinas</h5>
                <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
            </div>

            <form method="post" action="<?= base_url(); ?>/perjadin/selesai">
                <input type="hidden" name="id" id="id_perjadin">
                <div class="modal-body">
                    <table class="table">
                        <tr>
                            <td>Nama</td>
                            <td>:</td>
                            <td><span id="nama_pegawai"></span></td>
                        </tr>
                        <tr>
                            <td>Judul</td>
                            <td>:</td>
                            <td><span id="judul"></span></td>
                        </tr>
                        <tr>
                            <td>Deskripsi</td>
                            <td>:</td>
                            <td><span id="deskripsi"></span></td>
                        </tr>
                        <tr>
                            <td>Tanggal</td>
                            <td>:</td>
                            <td><span id="tanggal_pergi"></span> sampai <span id="tanggal_pulang"></span></td>
                        </tr>
                        <tr>
                            <td>Durasi</td>
                            <td>:</td>
                            <td><span id="durasi"> </span> hari</td>
                        </tr>
                        <tr>
                            <td>Tujuan</td>
                            <td>:</td>
                            <td><span id="nama_satker"></span></td>
                        </tr>

                    </table>

                    <h5>Permasalahan</h5>

                    <span id="permasalahan"></span>


                    <h5>Solusi</h5>

                    <span id="solusi"></span>
                    <h5>Dokumentasi Perjalanan Dinas </h5>
                    <div class="row">
                        <?php foreach ($dokumentasi_perjadin as $key => $value) {

                        ?>
                            <div class="col-sm-6 col-lg-3">
                                <div class="card">
                                    <div class="card-img-actions m-1">
                                        <img class="card-img img-fluid" src="<?= base_url('upload_file/perjadin/') . $value['nama_file'] ?>" alt="">
                                        <div class="card-img-actions-overlay card-img">
                                            <a href="<?= base_url('upload_file/perjadin/') . $value['nama_file'] ?>" class="btn btn-outline bg-white text-white border-white border-2 btn-icon rounded-round" data-popup="lightbox" rel="group">
                                                <i class="icon-plus3"></i>
                                            </a>

                                            <a href="#" class="btn btn-outline bg-white text-white border-white border-2 btn-icon rounded-round ml-2">
                                                <i class="icon-link"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>


                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
                    <!-- <button type="submit" class="btn bg-primary">Submit</button> -->
                </div>
            </form>
        </div>
    </div>
</div>
<!-- /vertical form modal -->
<!-- Vertical form modal -->
<div id="modal_hapus" class="modal fade" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Hapus Kegiatan</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <form method="post" action="<?= base_url(); ?>/perjadin/hapus">
                <input type="hidden" name="id" id="hapus_id">
                <div class="modal-body">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-sm-12">
                                <label>Kegiatan</label>
                                <textarea class="form-control" disabled id="hapus" rows="3"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn bg-danger">Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- /vertical form modal -->

<!-- /vertical form modal -->
<!-- script untuk progress -->
<script src="<?= base_url(); ?>global_assets/js/plugins/tables/datatables/extensions/jszip/jszip.min.js"></script>
<script src="<?= base_url(); ?>global_assets/js/plugins/tables/datatables/extensions/pdfmake/pdfmake.min.js"></script>
<script src="<?= base_url(); ?>global_assets/js/plugins/tables/datatables/extensions/pdfmake/vfs_fonts.min.js"></script>
<script src="<?= base_url(); ?>global_assets/js/plugins/tables/datatables/extensions/buttons.min.js"></script>
<script src="<?= base_url(); ?>global_assets/js/demo_pages/datatables_extension_buttons_html5.js"></script>

<!-- script untuk modal -->
<script type="text/javascript">
    $(document).ready(function() {

        $('#modal_selesai').on('show.bs.modal', function(event) {
            var div = $(event.relatedTarget) // Tombol dimana modal di tampilkan
            var modal = $(this)

            // Isi nilai pada field
            modal.find('#judul').val(div.data('judul'));
            modal.find('#id_perjadin').attr("value", div.data('id_perjadin'));
            modal.find('#permasalahan').focus();
            //modal.find('#email_to').attr("value",div.data(''));

        });


    });

    $(document).ready(function() {

        $('#modal_hapus').on('show.bs.modal', function(event) {
            var div = $(event.relatedTarget) // Tombol dimana modal di tampilkan
            var modal = $(this)

            // Isi nilai pada field
            modal.find('#hapus').val(div.data('perjadin'));
            modal.find('#hapus_id').attr("value", div.data('id'));
            //modal.find('#email_to').attr("value",div.data(''));

        });

    });

    $(document).ready(function() {
        function tanggal_indo(tanggal_full) {

            var bulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

            var xtahun = tanggal_full.substring(0, 4);
            var tanggal = tanggal_full.substr(8, 2);
            var xbulan = tanggal_full.substr(5, 2);

            var bulan = bulan[xbulan - 1];
            var tahun = (xtahun < 1000) ? xtahun + 1900 : xtahun;
            var tanggal_indo_ = (tanggal + ' ' + bulan + ' ' + tahun);
            return tanggal_indo_;
        }

        $('#modal_lihat').on('show.bs.modal', function(event) {
            var div = $(event.relatedTarget) // Tombol dimana modal di tampilkan
            var modal = $(this)


            // Isi nilai pada field
            modal.find('#judul').text(div.data('judul'));
            modal.find('#nama_pegawai').text(div.data('nama_pegawai'));
            modal.find('#deskripsi').text(div.data('deskripsi'));
            modal.find('#tanggal_pergi').text(tanggal_indo(div.data('tanggal_pergi')));
            modal.find('#tanggal_pulang').text(tanggal_indo(div.data('tanggal_pulang')));
            modal.find('#durasi').text(div.data('durasi'));
            modal.find('#nama_satker').text(div.data('nama_satker'));
            modal.find('#permasalahan').html(div.data('permasalahan'));
            modal.find('#solusi').html(div.data('solusi'));


            //modal.find('#email_to').attr("value",div.data(''));

        });

        $('#modal_setujui').on('show.bs.modal', function(event) {
            var div = $(event.relatedTarget) // Tombol dimana modal di tampilkan
            var modal = $(this)
            var link_tolak = "<?= base_url(); ?>perjadin/tolak/"
            var link_setujui = "<?= base_url(); ?>perjadin/setujui/"
            var tanggal = tanggal_indo(div.data('tanggal_pergi')) + " - " + tanggal_indo(div.data('tanggal_pulang'))

            // Isi nilai pada field
            modal.find('#judul_setujui').text(div.data('judul'));
            modal.find('#id_perjadin_setujui').text(div.data('id_perjadin'));
            modal.find('#nama_pegawai_setujui').text(div.data('nama_pegawai'));
            modal.find('#tanggal_setujui').text(tanggal);
            modal.find('#durasi_setujui').text(div.data('durasi'));
            modal.find('#nama_satker_setujui').text(div.data('nama_satker'));
            modal.find('#deskripsi_setujui').text(div.data('deskripsi'));
            modal.find('#link_tolak').attr("href", link_tolak + div.data('id_perjadin'));
            modal.find('#link_setujui').attr("href", link_setujui + div.data('id_perjadin'));

        });

    });
</script>
<script>
    CKEDITOR.replace('editor-full2', {
        height: 200,
        extraPlugins: 'forms'
    });
    CKEDITOR.replace('editor-full1', {
        height: 200,
        extraPlugins: 'forms'
    });
</script>